<?php

$array = [];

//caminho do ficheiro
$ficheiroBD = "bd/bd.txt";

//verificar se o ficheiro existe
if (file_exists($ficheiroBD)) {
    $conteudo = file_get_contents($ficheiroBD);  // Lê todo o conteúdo do arquivo
    $array = json_decode($conteudo,true);
} else {
    echo "O arquivo não existe.";
}

//tamanho do array
$max = sizeof($array);

//adiciona o cabeçalho da tabela
echo <<<HTML
	
<table style="width:100%">
  <tr>
    <th>Firstname</th>
	<th>Lastname</th>
	<th>Email</th>
	<th>Pass</th>
	<th>Data</th>
	<th>Tele</th>
	<th>Photo</th>
  </tr>


HTML;

//ciclo para mostrar a informação em formato de tabela
for ($i = 0; $i < $max; $i++){
	

	$firstname  = $array[$i]["firstname"];
	$lastname = $array[$i]["lastname"];
	$email = $array[$i]["email"];
	$pass = $array[$i]["password"];
	$data = $array[$i]["birthdate"];
	$tele = $array[$i]["mobilephone"];
	$photo = $array[$i]["photo"];

	//echo do resto da tabela com as variaveis
	echo <<<HTML
	<tr>
		<th>$firstname</th>
		<th>$lastname</th>
		<th>$email</th>
		<th>$pass</th>
		<th>$data</th>
		<th>$tele</th>
		<th>$photo</th>
	</tr>


	HTML;


}





?>