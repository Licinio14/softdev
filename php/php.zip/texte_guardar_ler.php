<?php
$array = array("1" => "primeiro","2" => "segundo");
$bd = json_encode($array);
print_r($array);

$ficheiroBD = "bd/bd.txt";

if (file_put_contents($ficheiroBD, $bd)) {
    echo "Conteúdo gravado com sucesso!";
} else {
    echo "Erro ao gravar o arquivo.";
}



if (file_exists($ficheiroBD)) {
    $conteudo = file_get_contents($ficheiroBD);  // Lê todo o conteúdo do arquivo
    $array = $conteudo;
	echo ($array);
} else {
    echo "O arquivo não existe.";
}

?>


<!DOCTYPE html>
<html>
<body>

<form method="post">
	<input type="submit" value="teste" name="submit">
</form>

</body>
</html>