<?php

//validar se foi inserida a linha
// $linha = -1;
if (empty($_GET['linha'])){
	$linha = -1;
}else{
	$linha = $_GET['linha'];
}

if (isset($_GET['linha']) && $_GET['linha'] === "0"){
	$linha = $_GET['linha'];
}

//validar se foi inserido o delete
if (empty($_GET['action'])){
	$action = -1;
	$apagar = false;
}else{
	$action = $_GET['action'];
	$validacao = strcasecmp($action, "delete");
	// validar se o utilizador escreveu delete (não importa maiusculas e minusculas)
	if ($validacao === 0){
		$apagar = true;
	}else{
		$apagar = false;
	}

}

$array = array();

//caminho do ficheiro
$ficheiroBD = "bd/bd.txt";

//verificar se o ficheiro existe
if (file_exists($ficheiroBD)) {
    $conteudo = file_get_contents($ficheiroBD);  // Lê todo o conteúdo do arquivo
    $array = json_decode($conteudo, true);
} else {
    echo "<h4 class='invaerro'>O arquivo não existe.</h4>";
}

//tamanho do array
$max = sizeof($array);


// se o apagar for true:
if ($apagar){

	//verificações da linha antes de apagar
	if ($linha == -1){
		echo "<h4 class='invaerro'>Não especificou a linha para apagar</h4>";
	}else if ($linha > $max){
		// echo "A opção linha vai de 0 a " . ($max - 1) . " !";
	}else if ($linha < -1) {
		echo "<h4 class='invaerro'>Não insira linhas negativas!</h4>";
	}else{
		//apagar a linha selecionada
		unset($array[$linha]);
		// Reindexámos o array
		$array = array_values($array);


		//passa o array para o formato json
		$bd = json_encode($array);
			
		//avisa que foi apagada a linha
		if (file_put_contents("bd/bd.txt", $bd)) {
			echo "<h1 style='
			text-align: center;
			margin-bottom: 20px;
			padding: 10px;
			background-color: #ddd;
			color: rgb(7, 105, 7);
			border-radius: 8px;
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
			'>Linha apagada com sucesso!</h1>";
		} else {
			echo "<h4 class='invaerro'>Erro ao gravar o arquivo.</h4>";
		}
		
		//termina a execução
		exit;


	}

}


?>

<!DOCTYPE html>
<html lang="pt">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Lista Formulario</title>
	<link rel="stylesheet" href="css/style.css">
</head>

<body class="bodyT">
	<h2 class="tabelaT">Lista do Formulário</h2>
	<!-- adiciona o cabeçalho da tabela -->
	<table>
		<thead>
			<tr>
				<th>Linha</th>
				<th>Firstname</th>
				<th>Lastname</th>
				<th>Email</th>
				<th>Pass</th>
				<th>Data</th>
				<th>Tele</th>
				<th>Photo</th>
			</tr>
		</thead>
		
<?php

		//verifica se foi usada uma linha valida ou nao
		if ($linha >= 0 && $linha < $max) {

			// vai buscar as informações pretendidas
			$firstname = $array[$linha]["firstname"];
			$lastname = $array[$linha]["lastname"];
			$email = $array[$linha]["email"];
			$pass = $array[$linha]["password"];
			$data = $array[$linha]["birthdate"];
			$tele = $array[$linha]["mobilephone"];
			$photo = $array[$linha]["photo"];


?>
		<tbody>
			<tr>
				<th><?php echo $linha ?></th>
				<th><?php echo $firstname ?></th>
				<th><?php echo $lastname ?></th>
				<th><?php echo $email ?></th>
				<th><?php echo $pass ?></th>
				<th><?php echo $data ?></th>
				<th><?php echo $tele ?></th>
				<th><?php echo $photo ?></th>
			</tr>
		</tbody>
<?php

		} else if ($linha == -1) {

			//ciclo para mostrar a informação em formato de tabela
			for ($i = 0; $i < $max; $i++){
				
				// vai buscar as informações pretendidas em ciclo
				$firstname  = $array[$i]["firstname"];
				$lastname = $array[$i]["lastname"];
				$email = $array[$i]["email"];
				$pass = $array[$i]["password"];
				$data = $array[$i]["birthdate"];
				$tele = $array[$i]["mobilephone"];
				$photo = $array[$i]["photo"];
		
				// $firstname = $arraytemp["firstname"];
				// $lastname = $arraytemp["lastname"];
				// $email = $arraytemp["email"];
				// $pass = $arraytemp["password"];
				// $data = $arraytemp["birthdate"];
				// $tele = $arraytemp["mobilephone"];
				// $photo = $arraytemp["photo"];


?>
				</tbody>
					<tr>
						<th><?php echo $i ?></th>
						<th><?php echo $firstname ?></th>
						<th><?php echo $lastname ?></th>
						<th><?php echo $email ?></th>
						<th><?php echo $pass ?></th>
						<th><?php echo $data ?></th>
						<th><?php echo $tele ?></th>
						<th><?php echo $photo ?></th>
					</tr>
				</tbody>
<?php
		}
	} else {
		// informa do mal preenchimento da linha
		echo "<h4 class='invaerro'>A opção linha vai de 0 a " . ($max - 1) . " ou -1 para mostrar tudo!</h4>";
	}

?>

	</table>
</body>

</html>