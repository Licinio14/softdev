<!--
Primeiro Nome
Apelidos
email
confirmação de email
password
confirmação da password
data de nascimento
telemovel
-->
<?php

//inicializar as variaveis vazias // atribui valores apenas para testes
$firstname = "Clara";
$lastname = "Carvalho";
$email = "a@gmail.com";
$confirmemail = "a@gmail.com";
$pass = "a1A!dedsefsef";
$confirmpass = "a1A!dedsefsef";
$data = "1988-04-23";
$tele = "912548795";
$errors = array();

//função para testar se a password é forte
function ValidarPass($pass){
		$forca = 0;

		if(/*verifica se contem letras maiusculas*/preg_match('/[A-Z]/', $pass)){
			$forca = $forca + 1;
		}
		if(/*verifica se contem letras minusculas*/preg_match('/[a-z]/', $pass)){
			$forca = $forca + 1;
		}
		if(/*verifica se contem caracteres especiais*/preg_match('/[\W_]/', $pass)){
			$forca = $forca + 1;
		}
		if(/*verifica se contem numeros*/preg_match('/[0-9]/', $pass)){
			$forca = $forca + 1;
		}

		return $forca;
		
}

if($_POST != null){
	
	//se quiser dar prit do array -> print_r($_POST);
	
	//atribuir os valures dos campos as variaveis
	$firstname  = $_POST["firstname"];
	$lastname = $_POST["lastname"];
	$email = $_POST["email"];
	$confirmemail = $_POST["confirmemail"];
	$pass = $_POST["password"];
	$confirmpass = $_POST["confirmpassword"];
	$data = $_POST["birthdate"];
	$tele = $_POST["mobilephone"];
	$verificarErros = 0;
	
	
	
	//testar se o nome esta preenchido e se tem mais de 2 letras
	if(empty($_POST["firstname"])){
		$verificarErros++;
		$errors["firstname"] = "O campo é de preenchimento obrigatorio";
	}else if(strlen(trim($_POST["firstname"])) < 3) {
		$verificarErros++;
		$errors["firstname"] = "O campo deve de ter pelo menos 3 caracteres";
	}else {
		$errors["firstname"] = "";
	}
	
	//testar se o apelido esta preenchido e se tem mais de 2 letras
	if(empty($_POST["lastname"])){
		$verificarErros++;
		$errors["lastname"] = "O campo é de preenchimento obrigatorio";
	}else if(strlen(trim($_POST["lastname"])) < 2) {
		$verificarErros++;
		$errors["lastname"] = "O campo deve de ter pelo menos 3 caracteres";
	}else {
		$errors["lastname"] = "";
	}
	
	//validação se o email esta preenchido e validar
	if(empty($_POST["email"])){
		$verificarErros++;
		$errors["email"] = "O campo é de preenchimento obrigatorio";
	}else if(/* função para validar o formato do email*/!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
		$verificarErros++;
		$errors["email"] = "O campo deve ser preechido com um email valido";
	}else {
		$errors["email"] = "";
	}
	
	//validação se o email esta igual ao inserido anterior
	if(empty($_POST["confirmemail"])){
		$verificarErros++;
		$errors["confirmemail"] = "O campo é de preenchimento obrigatorio";
	}else if($confirmemail != $email) {
		$verificarErros++;
		$errors["confirmemail"] = "O email é diferente do inserido anteriormente";
	}else {
		$errors["confirmemail"] = "";
	}
	
	//verifica se a password esta preenchida e depois valida || mostra o quao forte ela é
	if(empty($_POST["password"])){
		$verificarErros++;
		$errors["password"] = "O campo é de preenchimento obrigatorio";
	}else if(strlen(trim($_POST["password"])) < 8) {
		$verificarErros++;
		$errors["password"] = "A password tem de ter mais de 8 caracteres";
	}else if(/* função para ver se existe algum caracter do tipo*/!preg_match('/[A-Z]/', $_POST["password"])) {
		$verificarErros++;
		$errors["password"] = "A password tem de ter pelo menos uma maiuscula";
	}else if(/* função para ver se existe algum caracter do tipo*/!preg_match('/[\W_]/', $_POST["password"])) {
		$verificarErros++;
		$errors["password"] = "A password tem de ter pelo menos um caracter especial";
	}else if(/* função para ver se existe algum caracter do tipo*/!preg_match('/[0-9]/', $_POST["password"])) {
		$verificarErros++;
		$errors["password"] = "A password tem de ter pelo menos um caracter numerico";
	}
	
	//mostra se a password é forte
	if (!empty($_POST["password"])) {
		$forca = ValidarPass($_POST["password"]);
		if( $forca == 1 ){
			$errors["forcapassword"] = "Muito Fraca";
		}else if( $forca == 2 ){
			$errors["forcapassword"] = "Fraca";
		}else if( $forca == 3 ){
			$errors["forcapassword"] = "Forte";
		}else if( $forca == 4 ){
			$errors["forcapassword"] = "Muito Forte";
		}
	}
	
	//valida se a password é igual a inserida anteriormente
	if(empty($_POST["confirmpassword"])){
		$verificarErros++;
		$errors["confirmpassword"] = "O campo é de preenchimento obrigatorio";
	}else if(strlen(trim($_POST["password"])) < 8) {
		$verificarErros++;
		$errors["confirmpassword"] = "A password tem de ter mais de 8 caracteres";
	}else if($_POST["confirmpassword"] != $_POST["password"]){
		$verificarErros++;
		$errors["confirmpassword"] = "As passwords não sao iguais.";
	}else {
		$errors["confirmpassword"] = "";
	}

	//define o padrao para validar se é uma data
	$padrao = '/^\d{4}-\d{2}-\d{2}$/';

	//valida a data
	if (/* função para validar se a data esta no formato correto*/preg_match($padrao, $_POST["birthdate"])) {
		
		//atibui o respetivo valor as variaveis
		$month = substr($_POST["birthdate"],5,2);
		$day = substr($_POST["birthdate"],8,2);
		$year = substr($_POST["birthdate"],0,4);
		
		if(/*função para validar se a data existe*/checkdate($month, $day, $year)){
			//converte a data inserida de string para tipo data
			$data2 = new DateTime($_POST["birthdate"]);
			// vai buscar a data atual
			$data_atual = new DateTime();
			//calcula a diferença entre as datas
			$diferenca = $data_atual->diff($data2);
			//passa a quantidade de anos para a variavel
			$diferencano = $diferenca->y;
			//passa a quantidade de dias para a variavel
			$diferencadia = $diferenca->d;
			//passa a quantidade de meses para a variavel
			$diferencameses = $diferenca->m;
			// vai buscar apenas o ano atual
			$anoatual = date('Y');

			//faz as validaçoes da data
			if(empty($_POST["birthdate"])){
				$errors["birthdate"] = "O campo é de preenchimento obrigatorio";
				$verificarErros++;
			}else if(substr($_POST["birthdate"],0,4) > $anoatual){
				$errors["birthdate"] = "Insira uma data valida";
				$verificarErros++;
			}else if($diferencano > 120) {
				$errors["birthdate"] = "Nao pode ter mais de 120 anos";
				$verificarErros++;
			}else if($diferencano < 18 && $diferencano > 0){
				$errors["birthdate"] = "Nao pode ter menos de 18 anos";
				$verificarErros++;
			}else if($diferencadia == 0 && $diferencano == 0 && $diferencameses == 0){
				$errors["birthdate"] = "Não pode inserir a data de hoje";
				$verificarErros++;
			}else {
				$errors["birthdate"] = "";
			}
		}else {
			$verificarErros++;
			$errors["birthdate"] = "Insira uma data valida";
		}

	} else {
		$verificarErros++;
		$errors["birthdate"] = "Insira uma data valida";
	}

	//verifica o numero de telemovel
	if(empty($_POST["mobilephone"])){
		$verificarErros++;
		$errors["mobilephone"] = "O campo é de preenchimento obrigatorio";
	}else if(/*função para verificar se apenas contem numeros*/!preg_match_all('/[^0-9]/', $_POST["mobilephone"])){
		//verifica o tamanho e se contem o numero 9 na pocisao certa
		if (strlen(trim($_POST["mobilephone"])) == 9 && substr($_POST["mobilephone"],0,1) != 9) {
			$errors["mobilephone"] = "Só aceitamos números portugueses";
			$verificarErros++;
		}else if(strlen(trim($_POST["mobilephone"])) == 12 && substr($_POST["mobilephone"],3,1) != 9){
			$errors["mobilephone"] = "Só aceitamos números portugueses";
			$verificarErros++;
		}else if(strlen(trim($_POST["mobilephone"])) == 14 && substr($_POST["mobilephone"],5,1) != 9){
			$errors["mobilephone"] = "Só aceitamos números portugueses";
			$verificarErros++;
		}else if(strlen(trim($_POST["mobilephone"])) != 14 && strlen(trim($_POST["mobilephone"])) != 12 && strlen(trim($_POST["mobilephone"])) != 9){
			$errors["mobilephone"] = "O número tem de ter 9 caracteres ou 12 ou 14 caracteres, e nao pode conter \"+\"";
			$verificarErros++;
		}else {
			$errors["mobilephone"] = "";
		}
		
	}else {
		$verificarErros++;
		$errors["mobilephone"] = "Tem de inserir apenas números";
	}
	

	//verifica e mostra caso ja exista na bd
	$validacaoSeExiste = VerificarEmailTelefone($email,$tele);
	
	if($validacaoSeExiste == 1){
		
		$verificarErros++;
		$errors["submit"] = "O email ja existe";
		
	}else if ($validacaoSeExiste == 2){
		
		$verificarErros++;
		$errors["submit"] = "O telefone ja existe";
		
	}else if ($validacaoSeExiste == 3){
		
		$verificarErros++;
		$errors["submit"] = "O telefone e o email ja existe";
		
	}else {
		
		$errors["submit"] = "";
		
	}

	//verificar se pode dar upload da foto
	if($verificarErros == 0){
		//upload photo

		// obter a data e hora atual
		$data_photo = date('Y_m_d_H_i_s');
		
		// nome que vai ficar na foto
		$new_file_name =  $data_photo . "photo.png";
		
		//criação do caminho para guardar no array
		$target_dir = "uploads/";
		$target_file = $target_dir . $new_file_name;
		
		//caminho para as verificaçoes
		$target_file_old = $target_dir . basename($data_photo . $_FILES["fileToUpload"]["name"]);
		
		//se for 1 da upload a imagem, 0 nao da
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file_old,PATHINFO_EXTENSION));
		
		//valida se foi selecionado algo
		if(empty($_FILES["fileToUpload"]["name"])){
			$verificarErros++;
			$uploadOk = 1;
		}else{
			
			//vai verificar se é uma imagem
			$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			if($check !== false) {
				$uploadOk = 1;
			} else {
				$errors["fileToUpload"] = "O ficheiro não é uma imagem.";
				$uploadOk = 0;
			}
		
			// verifica o tamanho da imagem
			if ($_FILES["fileToUpload"]["size"] > 5000000) {
				$errors["fileToUpload"] = "O tamanho do ficheiro é maior ao permitido.";
				$uploadOk = 0;
				$verificarErros++;
			}
		}
		
		
		
			
		
		// verifica se a imagem ja existe
		if (file_exists($target_file_old)) {
			$errors["fileToUpload"] = "O ficheiro já existe.";
			$uploadOk = 0;
		}

		

		// verifica se é um dos formatos aceites
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			$errors["fileToUpload"] = "O ficheiro não é válido. Ficheiros válidos: JPG, JPEG, PNG & GIF.";
			$uploadOk = 0;
		}
		
		// $uploadOk == 0 teve erros, == 1 nao teve erros e pode mover a foto para o siteo correto
		if ($uploadOk == 0) {
			$errors["fileToUpload"] = "O ficheiro não foi carregado.";
			$verificarErros++;
		// if everything is ok, try to upload file
		} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file_old)) {
		} else {
			$errors["fileToUpload"] = "Ocorreu um erro ao carregar o ficheiro.";
			$verificarErros++;
		}
		}
	}

	
	
	
	
	
	
	//verifica se ocurreu erros antes de gravar no txt
	if($verificarErros == 0){
		GravarFormolario($target_file);
		$errors["submitform"] =  "<spam class='formsucesso'>Conteúdo gravado com sucesso!</spam>";
	}else{
		$errors["submitform"] =  "O formulario nao foi enviado";
	}


}


function VerificarEmailTelefone($email,$telefone){
	$jaExiste = 0;
	$emailVerificação = false;
	$telefoneVerificação = false;
	$array = [];
	
	//verifica se o ficheiro existe e copia os dados
	if(file_exists("bd/bd.txt")){
		$json = file_get_contents("bd/bd.txt");
		$array = json_decode($json, true);
	}
	if(!empty($array)){
		
		foreach ($array as $arraytemp) {
			if ($arraytemp['email'] === $email) {
				$emailVerificação = true;
				break;
			}
		}
		
		foreach ($array as $arraytemp) {
			if ($arraytemp['mobilephone'] === $telefone) {
				$telefoneVerificação = true;
				break;
			}
		}
	}
	
	
	if ($emailVerificação && $telefoneVerificação){
		
		return 3;
		
	}else if ($emailVerificação){
		
		return 1;
		
	}else if ($telefoneVerificação){
		
		return 2;
		
	}else {
		
		return 0;
		
	}

}
function GravarFormolario($foto){

	$array = [];

	//passa o POST para um array para alterala
	$postAlterado = $_POST;
	
	//adiciona o caminho da foto ao array
	$postAlterado["photo"] = $foto;
	
	//elimina do array as posiçoes mensionadas
	unset($postAlterado['confirmemail']);
	unset($postAlterado['confirmpassword']);
	
	//verifica se o ficheiro existe e copia os dados
	if(file_exists("bd/bd.txt")){
        $json = file_get_contents("bd/bd.txt");
        $array = json_decode($json, true);
    }
	
	//adiciona o conteudo do formulario ao array
	$array[] = $postAlterado;
	
	//passa o array para o formato json
	$bd = json_encode($array);
		
	//verifica se conseguio gravar
	if (file_put_contents("bd/bd.txt", $bd)) {
	} else {
		$errors["submitform"] =  "Erro ao gravar o arquivo.";
	}
}



?>

<!DOCTYPE html>
<html lang="pt">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Form</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body class="bodyF">
	<div>
		<form id="myform" method="post" enctype="multipart/form-data">
			<fieldset>
				<legend>First Name: </legend>
				<input type="text" name="firstname" id="firstname" value="<?php echo ($firstname);?>" placeholder="Insira o seu nome"><br>
				<span class="error"><?php if(isset($errors["firstname"])){echo $errors["firstname"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Last Name: </legend>
				<input type="text" name="lastname" id="lastname" value="<?php echo ($lastname);?>" placeholder="Insira o seu apelido"><br>
				<span class="error"><?php if(isset($errors["lastname"])){echo $errors["lastname"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Email: </legend>
				<input type="text" name="email" id="email" value="<?php echo ($email);?>" placeholder="Insira o seu email"><br>
				<span class="error"><?php if(isset($errors["email"])){echo $errors["email"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Confirm Email</legend>
				<input type="text" name="confirmemail" id="confirmemail" value="<?php echo ($confirmemail);?>" placeholder="Confirme o seu email"><br>
				<span class="error"><?php if(isset($errors["confirmemail"])){echo $errors["confirmemail"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Password</legend>
				<input type="password" name="password" id="password" value="<?php echo ($pass);?>" placeholder="Insira a sua password"><br>
				<span class="passforca"><?php if(isset($errors["forcapassword"])){echo $errors["forcapassword"]; echo "<br>";} ?></spam>

				<span class="error"><?php if(isset($errors["password"])){echo $errors["password"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Confirm Password</legend>
				<input type="password" name="confirmpassword" id="confirmpassword" value="<?php echo ($confirmpass);?>" placeholder="Confirme a sua password"><br>
				<span class="error"><?php if(isset($errors["confirmpassword"])){echo $errors["confirmpassword"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Data de Nascimento</legend>
				<input type="date" name="birthdate" id="birthdate" value="<?php echo ($data);?>" placeholder="Insira a sua data de nascimento"><br>
				<span class="error"><?php if(isset($errors["birthdate"])){echo $errors["birthdate"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Telemovel</legend>
				<input type="text" name="mobilephone" id="mobilephone" value="<?php echo ($tele);?>" placeholder="Insira o seu telemovel"><br>
				<span class="error"><?php if(isset($errors["mobilephone"])){echo $errors["mobilephone"];} ?></spam>
			</fieldset>
			<fieldset>
				<legend>Photo</legend>
				<input type="file" name="fileToUpload" id="fileToUpload"><br>
				<span class="error"><?php if(isset($errors["fileToUpload"])){echo $errors["fileToUpload"];} ?></spam>
			</fieldset>
			<button type="submit">Enviar</button>
			<span class="error"><?php if(isset($errors["submit"])){echo $errors["submit"];} ?></spam><br>
			<span class="error"><?php if(isset($errors["submitform"])){echo $errors["submitform"];} ?></spam>
		</form>
	</div>
</body>
</html>